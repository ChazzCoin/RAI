from setuptools import setup, find_packages

setup(
    name='rai',
    version='0.1',
    description='Rai Core',
    author='ChazzCoin',
    author_email='rail@rai.software',
    packages=find_packages(),  # Automatically find all packages (like 'rai' and submodules)
    install_requires=[],       # List any dependencies your package requires
)
