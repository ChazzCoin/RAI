from rai.RAG.db import ChromaClient

VECTOR_DB_CLIENT = ChromaClient()
